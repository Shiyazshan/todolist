import logo from './logo.svg';
import './App.css';

import ToDo from './Components/Screens/ToDo';

function App() {
  return (
   <ToDo/>
  );
}

export default App;
